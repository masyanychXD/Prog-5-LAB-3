from setuptools import setup

setup(name='maximspiryanovLab3',
      version='1.0',
      description='weather',
      packages=['maximspiryanovLab3'],
      author_email='maxim87858@mail.ru',
      zip_safe=False)